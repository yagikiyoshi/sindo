#    SINDO=/path/to/FSindo/bin/sindo
    SINDO=/Users/kyagi/Work/devel/sindo/sindo.master/FSindo/bin/sindo

    ${SINDO} < vscf.inp   > vscf.out   2>&1
    ${SINDO} < vmp2.inp   > vmp2.out   2>&1
    ${SINDO} < vqdpt2.inp > vqdpt2.out 2>&1
    ${SINDO} < vci.inp    > vci.out    2>&1

